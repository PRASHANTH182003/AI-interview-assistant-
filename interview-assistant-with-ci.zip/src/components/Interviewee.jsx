import React, {useState, useRef, useEffect} from 'react'
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.js';
import mammoth from 'mammoth';

const SAMPLE_QUESTIONS = [
  // 2 Easy
  {level:'Easy', time:20, text:'Explain the difference between let, const and var in JavaScript.'},
  {level:'Easy', time:20, text:'What is JSX and why is it used in React?'},
  // 2 Medium
  {level:'Medium', time:60, text:'Describe how useEffect works and give an example use-case.'},
  {level:'Medium', time:60, text:'Explain how to manage global state in a React app.'},
  // 2 Hard
  {level:'Hard', time:120, text:'Design a system for real-time notifications in a full-stack app.'},
  {level:'Hard', time:120, text:'Explain pros/cons of server-side rendering vs client-side rendering.'}
];

function extractTextFromPDF(file){
  return new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onload = async function(){
      try{
        const typed = new Uint8Array(reader.result);
        const doc = await pdfjsLib.getDocument({data: typed}).promise;
        let txt = '';
        for(let i=1;i<=doc.numPages;i++){
          const page = await doc.getPage(i);
          const content = await page.getTextContent();
          const strs = content.items.map(s=>s.str).join(' ');
          txt += '\n' + strs;
        }
        resolve(txt);
      }catch(e){reject(e)}
    }
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  })
}

async function extractTextFromDocx(file){
  const arrayBuffer = await file.arrayBuffer();
  const res = await mammoth.extractRawText({arrayBuffer});
  return res.value;
}

function simpleParseContact(text){
  const emailMatch = text.match(/[\w.-]+@[\w.-]+\.[A-Za-z]{2,6}/);
  const phoneMatch = text.match(/(\+?\d[\d\s-]{6,}\d)/);
  const nameMatch = text.split('\n').map(l=>l.trim()).find(l=>l && l.split(' ').length<=4 && /[A-Za-z]/.test(l));
  return {
    name: nameMatch || '',
    email: emailMatch ? emailMatch[0] : '',
    phone: phoneMatch ? phoneMatch[0] : ''
  }
}

export default function Interviewee(){
  const [resumeText, setResumeText] = useState('')
  const [profile, setProfile] = useState(()=> JSON.parse(localStorage.getItem('candidate_profile')||'null'))
  const [messages, setMessages] = useState(()=> JSON.parse(localStorage.getItem('chat_messages')||'[]'))
  const [currentQIndex, setCurrentQIndex] = useState(()=> Number(localStorage.getItem('current_q')||0))
  const [timeLeft, setTimeLeft] = useState(0)
  const timerRef = useRef(null)
  const [inProgress, setInProgress] = useState(()=> localStorage.getItem('in_progress')==='true')
  const [showWelcomeBack, setShowWelcomeBack] = useState(false)

  useEffect(()=> localStorage.setItem('chat_messages', JSON.stringify(messages)), [messages])
  useEffect(()=> localStorage.setItem('candidate_profile', JSON.stringify(profile||{})), [profile])
  useEffect(()=> localStorage.setItem('current_q', String(currentQIndex)), [currentQIndex])
  useEffect(()=> localStorage.setItem('in_progress', inProgress?'true':'false'), [inProgress])

  useEffect(()=>{
    // if unfinished session exists, show welcome back
    const unfinished = localStorage.getItem('in_progress')==='true' && (!profile || messages.length<6);
    setShowWelcomeBack(!!unfinished);
  },[])

  useEffect(()=>{
    if(inProgress){
      const q = SAMPLE_QUESTIONS[currentQIndex];
      if(q){
        setTimeLeft(q.time);
      } else {
        setTimeLeft(0);
      }
    } else {
      clearInterval(timerRef.current);
    }
  },[inProgress, currentQIndex])

  useEffect(()=>{
    if(timeLeft>0){
      timerRef.current = setInterval(()=> setTimeLeft(t=> t-1), 1000);
      return ()=> clearInterval(timerRef.current)
    } else {
      // auto submit if timer reached 0 and interview in progress
      if(inProgress){
        handleSubmitAnswer('') // auto-submit empty if time ran out
      }
    }
  },[timeLeft])

  async function handleResumeFile(e){
    const file = e.target.files[0];
    if(!file) return;
    let text='';
    if(file.name.toLowerCase().endsWith('.pdf')){
      text = await extractTextFromPDF(file);
    } else if(file.name.toLowerCase().endsWith('.docx')){
      text = await extractTextFromDocx(file);
    } else {
      alert('Unsupported file type. Please use PDF or DOCX.')
      return;
    }
    setResumeText(text);
    const parsed = simpleParseContact(text);
    setProfile(old => ({...(old||{}), ...parsed}));
    alert('Resume parsed. Fill any missing fields in profile section.')
  }

  function updateProfileField(k, v){
    setProfile(p=> ({...(p||{}), [k]:v}))
  }

  function startInterview(){
    if(!profile || !profile.name || !profile.email){
      alert('Please fill Name and Email at minimum before starting.')
      return;
    }
    setInProgress(true);
    setShowWelcomeBack(false);
    if(messages.length===0){
      // push first question
      setMessages([{role:'system', text:'Interview started.'}])
      setCurrentQIndex(0)
    }
  }

  function handleSubmitAnswer(text){
    // score simple: length + keyword checks
    const q = SAMPLE_QUESTIONS[currentQIndex];
    const score = Math.min(100, Math.round(Math.min(1, (text.length/30)) * 100));
    const msg = {role:'candidate', question:q ? q.text : 'N/A', answer:text, score, level:q? q.level:''}
    setMessages(m=> [...m, msg])
    if(currentQIndex < SAMPLE_QUESTIONS.length-1){
      setCurrentQIndex(i=> i+1)
    } else {
      // finished
      setInProgress(false);
      // compute final summary
      const answers = [...messages, msg].filter(m=>m.role==='candidate');
      const avg = Math.round(answers.reduce((s,a)=>s + (a.score||0),0) / answers.length || 0)
      const summary = {finalScore: avg, summaryText: 'Auto-generated summary: Candidate answered questions; average score '+avg}
      // persist to candidates list
      const all = JSON.parse(localStorage.getItem('candidates')||'[]')
      const candidate = {id: Date.now(), profile, messages:[...answers], finalScore: avg, summary}
      localStorage.setItem('candidates', JSON.stringify([candidate, ...all]))
      alert('Interview finished. Summary saved to dashboard.')
    }
  }

  function resumeSession(){
    setInProgress(true);
    setShowWelcomeBack(false);
  }

  function resetSession(){
    if(confirm('Reset current session?')){
      setProfile(null);
      setMessages([]);
      setCurrentQIndex(0);
      setInProgress(false);
      localStorage.removeItem('candidate_profile');
      localStorage.removeItem('chat_messages');
      localStorage.removeItem('current_q');
      localStorage.removeItem('in_progress');
    }
  }

  return (
    <div>
      <h2>Interviewee (Chat)</h2>
      {showWelcomeBack && <div style={{padding:12,background:'#fff4e5',border:'1px solid #ffd8a8',marginBottom:12}}>
        <strong>Welcome back!</strong> You have an unfinished interview. <button onClick={resumeSession}>Resume</button> or <button onClick={resetSession}>Discard</button>
      </div>}
      <div style={{display:'flex',gap:12}}>
        <div style={{flex:1}}>
          <label><strong>Upload Resume (PDF or DOCX)</strong></label><br/>
          <input type="file" accept=".pdf,.docx" onChange={handleResumeFile} />
          <div style={{marginTop:8}}>
            <strong>Parsed Profile</strong>
            <div>
              <input placeholder="Name" value={(profile&&profile.name)||''} onChange={e=>updateProfileField('name', e.target.value)} />
            </div>
            <div>
              <input placeholder="Email" value={(profile&&profile.email)||''} onChange={e=>updateProfileField('email', e.target.value)} />
            </div>
            <div>
              <input placeholder="Phone" value={(profile&&profile.phone)||''} onChange={e=>updateProfileField('phone', e.target.value)} />
            </div>
            <div style={{marginTop:8}}>
              <button onClick={startInterview}>Start Interview</button>
              <button onClick={resetSession} style={{marginLeft:8}}>Reset</button>
            </div>
          </div>
        </div>
        <div style={{width:360}}>
          <div className="chat">
            {messages.map((m,i)=> (
              <div key={i} style={{marginBottom:8}}>
                {m.role==='system' && <div className="small">{m.text}</div>}
                {m.role==='candidate' && <div><strong>Q:</strong> {m.question}<br/><strong>A:</strong> {m.answer}<br/><span className="small">Score: {m.score}</span></div>}
              </div>
            ))}
            {inProgress && <div style={{marginTop:8}}>
              <strong>Question:</strong> {SAMPLE_QUESTIONS[currentQIndex] ? SAMPLE_QUESTIONS[currentQIndex].text : '...'}
              <div className="small">Level: {SAMPLE_QUESTIONS[currentQIndex]?.level} — Time left: {timeLeft}s</div>
            </div>}
          </div>
          <div className="controls">
            <AnswerBox onSubmit={(text)=> handleSubmitAnswer(text)} disabled={!inProgress} />
          </div>
        </div>
      </div>
    </div>
  )
}

function AnswerBox({onSubmit, disabled}){
  const [text, setText] = useState('')
  return (
    <div style={{display:'flex',gap:8,width:'100%'}}>
      <input style={{flex:1}} value={text} onChange={e=>setText(e.target.value)} placeholder={disabled? 'Answer the current question...' : 'Start interview to answer'} />
      <button onClick={()=>{ onSubmit(text); setText('') }} disabled={!disabled}>Submit</button>
    </div>
  )
}
