import React, {useState, useEffect} from 'react'

export default function Interviewer(){
  const [candidates, setCandidates] = useState(()=> JSON.parse(localStorage.getItem('candidates')||'[]'))
  const [selected, setSelected] = useState(null)
  const [query, setQuery] = useState('')

  useEffect(()=> {
    const onStorage = ()=> setCandidates(JSON.parse(localStorage.getItem('candidates')||'[]'))
    window.addEventListener('storage', onStorage)
    return ()=> window.removeEventListener('storage', onStorage)
  },[])

  function refresh(){ setCandidates(JSON.parse(localStorage.getItem('candidates')||'[]')) }

  const filtered = candidates.filter(c=> c.profile?.name?.toLowerCase().includes(query.toLowerCase()))
  const sorted = filtered.sort((a,b)=> b.finalScore - a.finalScore)

  return (
    <div>
      <h2>Interviewer (Dashboard)</h2>
      <div style={{display:'flex',gap:12}}>
        <div style={{width:360}}>
          <div style={{display:'flex',gap:8,marginBottom:8}}>
            <input placeholder="Search by name" value={query} onChange={e=>setQuery(e.target.value)} />
            <button onClick={refresh}>Refresh</button>
          </div>
          <div>
            {sorted.map(c=> (
              <div className="candidate" key={c.id} onClick={()=>setSelected(c)}>
                <div>
                  <div><strong>{c.profile?.name||'Unnamed'}</strong></div>
                  <div className="meta">{c.profile?.email || '—'} • Score: {c.finalScore}</div>
                </div>
                <div>
                  <div className="small">View</div>
                </div>
              </div>
            ))}
            {sorted.length===0 && <div className="small">No candidates yet. Run an interview in the Interviewee tab.</div>}
          </div>
        </div>
        <div style={{flex:1}}>
          {selected ? <CandidateDetail c={selected} /> : <div className="small">Select a candidate to view details</div>}
        </div>
      </div>
    </div>
  )
}

function CandidateDetail({c}){
  return (
    <div>
      <h3>{c.profile?.name}</h3>
      <div className="small">Email: {c.profile?.email} • Phone: {c.profile?.phone}</div>
      <div style={{marginTop:12}}>
        <strong>Summary</strong>
        <div>{c.summary.summaryText} — Final Score: {c.finalScore}</div>
      </div>
      <div style={{marginTop:12}}>
        <strong>Q & A</strong>
        <div>
          {c.messages.map((m,i)=> (
            <div key={i} style={{padding:8,borderBottom:'1px solid #f0f0f0'}}>
              <div><strong>Q:</strong> {m.question}</div>
              <div><strong>A:</strong> {m.answer || '(no answer)'}</div>
              <div className="small">Score: {m.score}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
