import React, { useState, useEffect } from 'react'
import Interviewee from './components/Interviewee'
import Interviewer from './components/Interviewer'

export default function App(){
  const [tab, setTab] = useState(localStorage.getItem('tab') || 'interviewee')
  useEffect(()=> localStorage.setItem('tab', tab), [tab])
  return (
    <div className="container">
      <h1>AI Interview Assistant</h1>
      <div className="tabs">
        <button className={tab==='interviewee' ? 'active': ''} onClick={()=>setTab('interviewee')}>Interviewee (Chat)</button>
        <button className={tab==='interviewer' ? 'active': ''} onClick={()=>setTab('interviewer')}>Interviewer (Dashboard)</button>
      </div>
      <main>
        {tab==='interviewee' ? <Interviewee /> : <Interviewer />}
      </main>
    </div>
  )
}
