# AI Interview Assistant (Minimal)

This is a minimal, local-first React + Vite project that implements the core features requested in the assignment:
- Two tabs: Interviewee (chat) and Interviewer (dashboard).
- Resume upload (PDF/DOCX). Basic extraction of Name/Email/Phone using heuristics.
- Interview flow with 6 questions (2 Easy, 2 Medium, 2 Hard) and timers per question.
- Auto-submit when time runs out.
- Persistence using `localStorage`. Unfinished sessions show a 'Welcome Back' modal.
- Dashboard lists candidates, allows viewing full Q&A and summary.
- Simple mocked scoring (length-based + heuristics). Replace with an AI API if desired.

## How to run

1. Ensure Node.js (>=16) and npm are installed.
2. Extract the zip and in the project folder run:

```bash
npm install
npm run dev
```

3. Open `http://localhost:5173` (or the URL printed by Vite).

## Notes & Next steps

- The PDF parsing uses `pdfjs-dist` and DOCX uses `mammoth`. Parsing is heuristic — you may want to improve with an LLM or regex for better accuracy.
- AI question generation and scoring are mocked with static questions and simple scoring. To use a real AI, replace the scoring/generation logic in `src/components/Interviewee.jsx` with calls to your AI endpoint (OpenAI, etc.). Be mindful to store API keys securely (server-side).
- Persistence is via `localStorage` to keep things simple. For production, use IndexedDB or backend storage.
- The UI is intentionally minimal. Feel free to swap in Ant Design or shadcn for a more polished UI.

## Deliverables checklist (what this bundle contains)

- Source code (React + Vite)
- README with instructions

## Files

- `package.json`, `vite.config.js`, `index.html`
- `src/` — React source, components, styles

If you want, I can:
- Add a GitHub Actions workflow and deploy to Netlify/Vercel,
- Implement real AI integration using an API,
- Improve resume parsing accuracy,
- Convert to TypeScript or add Redux + redux-persist.

